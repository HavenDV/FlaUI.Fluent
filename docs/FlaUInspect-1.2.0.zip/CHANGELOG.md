# Changelog

## 1.2.0 (2017-05-24)

### Enhancements
  * Moved to its own repository
  * New logo

## Older changes
See https://raw.githubusercontent.com/Roemer/FlaUI/master/CHANGELOG.md